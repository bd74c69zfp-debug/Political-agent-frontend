const fs = require('fs');
const path = require('path');
const { google } = require('googleapis');

async function uploadVideo(auth, { videoFile, title, description, tags, privacy }) {
  const youtube = google.youtube({ version: 'v3', auth });
  const res = await youtube.videos.insert({
    part: ['snippet', 'status'],
    requestBody: {
      snippet: { title, description, tags, categoryId: '25' },
      status: { privacyStatus: privacy }
    },
    media: { body: fs.createReadStream(path.resolve(videoFile)) }
  });
  return res.data;
}

module.exports = { uploadVideo };