const { google } = require('googleapis');

function createAuth({ clientId, clientSecret, redirectUri, refreshToken }) {
  const auth = new google.auth.OAuth2(clientId, clientSecret, redirectUri);
  auth.setCredentials({ refresh_token: refreshToken });
  return auth;
}

module.exports = { createAuth };