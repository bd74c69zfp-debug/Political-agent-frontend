const express = require('express');
const path = require('path');
const { createServer } = require('./server');
const { createAuth } = require('./auth');
const { uploadVideo } = require('./upload');
const { prisma } = require('./db');
const { authRouter } = require('./auth-login');
const config = require('./config');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/auth', authRouter());

let logs = [];
async function log(message) {
  logs.unshift({ ts: new Date().toISOString(), message });
  logs = logs.slice(0, 20);
  try { await prisma.logEntry.create({ data: { message } }); } catch (e) {}
}

function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return res.status(401).json({ error: 'Unauthorized' });
  next();
}

app.get('/api/state', requireAuth, (req, res) => {
  const queue = await prisma.topic.findMany({ orderBy: { createdAt: 'desc' } });
  res.json({ queue, logs });
});

app.post('/api/topics', requireAuth, async (req, res) => {
  const item = await prisma.topic.create({
    data: {
      topic: req.body.topic || 'Untitled',
      region: req.body.region || 'US politics',
      tone: req.body.tone || 'Neutral explainer',
      facts: Array.isArray(req.body.facts) ? req.body.facts.join('\n') : (req.body.facts || ''),
      stakes: req.body.stakes || '',
      status: 'draft'
    }
  });
  await log(`Created topic: ${item.topic}`);
  res.json(item);
});

app.post('/api/queue/:id/approve', requireAuth, async (req, res) => {
  const item = await prisma.topic.update({ where: { id: req.params.id }, data: { status: 'approved' } }).catch(() => null);
  if (!item) return res.status(404).json({ error: 'Not found' });
  await log(`Approved: ${item.topic}`);
  res.json(item);
});

app.post('/api/queue/:id/publish', requireAuth, async (req, res) => {
  const item = await prisma.topic.update({ where: { id: req.params.id }, data: { status: 'published' } }).catch(() => null);
  if (!item) return res.status(404).json({ error: 'Not found' });
  await log(`Published: ${item.topic}`);
  if (process.env.MODE !== 'webhook' && config.clientId && config.refreshToken) {
    try {
      const auth = createAuth(config);
      const result = await uploadVideo(auth, config);
      await prisma.topic.update({ where: { id: item.id }, data: { youtubeId: result.id } });
      await log(`YouTube upload done: ${result.id}`);
    } catch (e) {
      log(`YouTube upload failed: ${e.message}`);
    }
  }
  res.json(item);
});

app.get('/api/logs', requireAuth, async (req, res) => {
  const dbLogs = await prisma.logEntry.findMany({ orderBy: { createdAt: 'desc' }, take: 20 });
  res.json(dbLogs);
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Dashboard on ${port}`));
