const express = require('express');
const crypto = require('crypto');
const { sendText } = require('./whatsapp');

function createServer({ verifyToken, appSecret, phoneNumberId, token }) {
  const app = express();
  app.use(express.json({ verify: (req, res, buf) => { req.rawBody = buf; } }));

  app.get('/webhook', (req, res) => {
    const mode = req.query['hub.mode'];
    const challenge = req.query['hub.challenge'];
    const tokenCheck = req.query['hub.verify_token'];
    if (mode === 'subscribe' && tokenCheck === verifyToken) return res.status(200).send(challenge);
    return res.sendStatus(403);
  });

  app.post('/webhook', async (req, res) => {
    const signature = req.get('x-hub-signature-256') || '';
    const expected = 'sha256=' + crypto.createHmac('sha256', appSecret).update(req.rawBody).digest('hex');
    if (!signature || signature !== expected) return res.sendStatus(403);

    try {
      const body = req.body;
      const msg = body?.entry?.[0]?.changes?.[0]?.value?.messages?.[0];
      const from = msg?.from;
      const text = msg?.text?.body?.trim().toLowerCase() || '';
      if (from) {
        let reply = 'Commands: /topstory, /script, /shorts, /queue, /approve';
        if (text.startsWith('/topstory')) reply = 'Top story queued. Open dashboard to review the latest item.';
        else if (text.startsWith('/script')) reply = 'Script draft requested. Check the dashboard for the generated package.';
        else if (text.startsWith('/shorts')) reply = 'Shorts draft requested.';
        else if (text.startsWith('/queue')) reply = 'Queue is available in the dashboard.';
        else if (text.startsWith('/approve')) reply = 'Approved. Item marked ready for production.';
        await sendText({ phoneNumberId, token, to: from, text: reply });
      }
      return res.sendStatus(200);
    } catch (e) {
      return res.sendStatus(200);
    }
  });

  return app;
}

module.exports = { createServer };