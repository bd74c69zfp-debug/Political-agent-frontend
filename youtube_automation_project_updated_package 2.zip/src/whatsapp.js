const axios = require('axios');

function sendText({ phoneNumberId, token, to, text }) {
  const url = `https://graph.facebook.com/v19.0/${phoneNumberId}/messages`;
  return axios.post(url, {
    messaging_product: 'whatsapp',
    to,
    type: 'text',
    text: { body: text }
  }, {
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  });
}

module.exports = { sendText };